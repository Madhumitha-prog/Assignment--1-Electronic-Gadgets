package com.hexaware.programtest;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.hexaware.dao.AssetManagementService;
import com.hexaware.dao.AssetManagementServiceImpl;
import com.hexaware.exception.AssetNotFoundException;
import com.hexaware.exception.AssetNotMaintainException;
import com.hexaware.model.Asset;

class AssetManagementTest {
	AssetManagementService assetService = new AssetManagementServiceImpl();

	@Test
	public void testAddAssetSuccessfully() {
	    Asset asset = new Asset();
	    asset.setName("Test Laptop");
	    asset.setType("Electronics");
	    asset.setSerialNumber("SN123456");
	    asset.setPurchaseDate(Date.valueOf("2024-01-01"));
	    asset.setLocation("Office A");
	    asset.setStatus("available");
	    asset.setOwnerId(1);

	    boolean result = assetService.addAsset(asset);
	    Assertions.assertTrue(result, "Asset should be added successfully.");
	}


	@Test
	public void testPerformMaintenanceSuccessfully() throws AssetNotMaintainException {
	    int assetId = 1; // Ensure this exists in test DB
	    String maintenanceDate = "2025-05-10";
	    String description = "Battery replacement";
	    double cost = 120.0;

	    boolean result = assetService.performMaintenance(assetId, maintenanceDate, description, cost);
	    Assertions.assertTrue(result, "Maintenance should be recorded successfully.");
	}


	@Test
	public void testReserveAssetSuccessfully() {
	    int assetId = 1;       // Should exist
	    int employeeId = 2;    // Should exist
	    String reservationDate = "2025-05-11";
	    String startDate = "2025-05-12";
	    String endDate = "2025-05-15";

	    boolean result = assetService.reserveAsset(assetId, employeeId, reservationDate, startDate, endDate);
	    Assertions.assertTrue(result, "Reservation should be successful.");
	}


	@Test
	public void testAllocateAssetThrowsExceptionForInvalidAssetId() {
	    int invalidAssetId = 9999;  // Ensure does not exist
	    int employeeId = 2;
	    String allocationDate = "2025-05-11";

	    Assertions.assertThrows(AssetNotFoundException.class, () -> {
	        assetService.allocateAsset(invalidAssetId, employeeId, allocationDate);
	    }, "Should throw AssetNotFoundException when asset does not exist.");
	}

}
