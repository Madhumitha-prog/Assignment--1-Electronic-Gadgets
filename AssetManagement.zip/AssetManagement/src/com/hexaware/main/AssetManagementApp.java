package com.hexaware.main;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.hexaware.dao.AssetManagementService;
import com.hexaware.dao.AssetManagementServiceImpl;
import com.hexaware.exception.AssetNotFoundException;
import com.hexaware.exception.AssetNotMaintainException;
import com.hexaware.model.Asset;

public class AssetManagementApp {
	

	public static void main(String[] args) {
		
		AssetManagementServiceImpl ami = new AssetManagementServiceImpl();
		ami.showCOnnection();
		
		Scanner scanner = new Scanner(System.in);
        AssetManagementService service = new AssetManagementServiceImpl();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        while (true) {
            System.out.println("\n----- Digital Asset Management System -----");
            System.out.println("1. Add Asset");
            System.out.println("2. Update Asset");
            System.out.println("3. Delete Asset");
            System.out.println("4. Allocate Asset");
            System.out.println("5. Deallocate Asset");
            System.out.println("6. Perform Maintenance");
            System.out.println("7. Reserve Asset");
            System.out.println("8. Withdraw Reservation");
            System.out.println("9. Exit");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            try {
                switch (choice) {
                    case 1: // Add Asset
                        System.out.print("Asset Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Type: ");
                        String type = scanner.nextLine();
                        System.out.print("Serial Number: ");
                        String serial = scanner.nextLine();
                        System.out.print("Purchase Date (yyyy-MM-dd): ");
                        Date purchaseDate = new Date (sdf.parse(scanner.nextLine()).getTime());
                        System.out.print("Location: ");
                        String location = scanner.nextLine();
                        System.out.print("Status: ");
                        String status = scanner.nextLine();
                        System.out.print("Owner ID: ");
                        int ownerId = scanner.nextInt();
                        scanner.nextLine();

                        Asset asset = new Asset(0, name, type, serial, purchaseDate, location, status, ownerId);
                        System.out.println(service.addAsset(asset) ? "Asset added successfully." : "Failed to add asset.");
                        break;

                    case 2: // Update Asset
                        System.out.print("Asset ID to update: ");
                        int updateId = scanner.nextInt(); scanner.nextLine();
                        System.out.print("New Name: ");
                        name = scanner.nextLine();
                        System.out.print("New Type: ");
                        type = scanner.nextLine();
                        System.out.print("New Serial Number: ");
                        serial = scanner.nextLine();
                        System.out.print("New Purchase Date (yyyy-MM-dd): ");
                        purchaseDate = new Date (sdf.parse(scanner.nextLine()).getTime());
                        System.out.print("New Location: ");
                        location = scanner.nextLine();
                        System.out.print("New Status: ");
                        status = scanner.nextLine();
                        System.out.print("New Owner ID: ");
                        ownerId = scanner.nextInt(); scanner.nextLine();

                        Asset updatedAsset = new Asset(updateId, name, type, serial, purchaseDate, location, status, ownerId);
                        System.out.println(service.updateAsset(updatedAsset) ? "Asset updated successfully." : "Failed to update asset.");
                        break;

                    case 3: // Delete Asset
                        System.out.print("Asset ID to delete: ");
                        int deleteId = scanner.nextInt();
                        System.out.println(service.deleteAsset(deleteId) ? "Asset deleted successfully." : "Failed to delete asset.");
                        break;

                    case 4: // Allocate Asset
                        System.out.print("Asset ID: ");
                        int allocAssetId = scanner.nextInt();
                        System.out.print("Employee ID: ");
                        int empId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Allocation Date (yyyy-MM-dd): ");
                        String allocDate = scanner.nextLine();
                        System.out.println(service.allocateAsset(allocAssetId, empId, allocDate)
                                ? "Asset allocated successfully." : "Failed to allocate asset.");
                        break;

                    case 5: // Deallocate Asset
                        System.out.print("Asset ID: ");
                        int deallocAssetId = scanner.nextInt();
                        System.out.print("Employee ID: ");
                        int deallocEmpId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Return Date (yyyy-MM-dd): ");
                        String returnDate = scanner.nextLine();
                        System.out.println(service.deallocateAsset(deallocAssetId, deallocEmpId, returnDate)
                                ? "Asset deallocated successfully." : "Failed to deallocate asset.");
                        break;

                    case 6: // Perform Maintenance
                        System.out.print("Asset ID: ");
                        int maintAssetId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Maintenance Date (yyyy-MM-dd): ");
                        String maintDate = scanner.nextLine();
                        System.out.print("Description: ");
                        String desc = scanner.nextLine();
                        System.out.print("Cost: ");
                        double cost = scanner.nextDouble();
                        scanner.nextLine();
                        System.out.println(service.performMaintenance(maintAssetId, maintDate, desc, cost)
                                ? "Maintenance recorded successfully." : "Failed to record maintenance.");
                        break;

                    case 7: // Reserve Asset
                        System.out.print("Asset ID: ");
                        int resAssetId = scanner.nextInt();
                        System.out.print("Employee ID: ");
                        int resEmpId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Reservation Date (yyyy-MM-dd): ");
                        String resDate = scanner.nextLine();
                        System.out.print("Start Date (yyyy-MM-dd): ");
                        String startDate = scanner.nextLine();
                        System.out.print("End Date (yyyy-MM-dd): ");
                        String endDate = scanner.nextLine();
                        System.out.println(service.reserveAsset(resAssetId, resEmpId, resDate, startDate, endDate)
                                ? "Reservation created successfully." : "Failed to create reservation.");
                        break;

                    case 8: // Withdraw Reservation
                        System.out.print("Reservation ID: ");
                        int resId = scanner.nextInt();
                        System.out.println(service.withdrawReservation(resId)
                                ? "Reservation withdrawn successfully." : "Failed to withdraw reservation.");
                        break;

                    case 9:
                        System.out.println("Exiting system. Goodbye!");
                        scanner.close();
                        return;

                    default:
                        System.out.println("Invalid option. Try again.");
                }
            }catch (AssetNotFoundException | AssetNotMaintainException e) {
                System.out.println("Error: " + e.getMessage());
            }catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
		
	}

}
