package com.hexaware.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.hexaware.exception.AssetNotFoundException;
import com.hexaware.exception.AssetNotMaintainException;
import com.hexaware.model.Asset;
import com.hexaware.util.DBConnUtil;

public class AssetManagementServiceImpl implements AssetManagementService  {
	 Connection conn = DBConnUtil.getConnection();

	@Override
	public boolean addAsset(Asset asset) {
		
		  String sql = "INSERT INTO assets (name, type, serial_number, purchase_date, location, status, owner_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
	        try (Connection conn = DBConnUtil.getConnection();
	             PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setString(1, asset.getName());
	            ps.setString(2, asset.getType());
	            ps.setString(3, asset.getSerialNumber());
	            ps.setDate(4, new java.sql.Date(asset.getPurchaseDate().getTime()));
	            ps.setString(5, asset.getLocation());
	            ps.setString(6, asset.getStatus());
	            ps.setInt(7, asset.getOwnerId());
	            return ps.executeUpdate() > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	}

	@Override
	public boolean updateAsset(Asset asset) {
		 String sql = "UPDATE assets SET name=?, type=?, serial_number=?, purchase_date=?, location=?, status=?, owner_id=? WHERE asset_id=?";
	        try (Connection conn = DBConnUtil.getConnection();
	             PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setString(1, asset.getName());
	            ps.setString(2, asset.getType());
	            ps.setString(3, asset.getSerialNumber());
	            ps.setDate(4, new java.sql.Date(asset.getPurchaseDate().getTime()));
	            ps.setString(5, asset.getLocation());
	            ps.setString(6, asset.getStatus());
	            ps.setInt(7, asset.getOwnerId());
	            ps.setInt(8, asset.getAssetId());
	            return ps.executeUpdate() > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	}

	@Override
	public boolean deleteAsset(int assetId) throws AssetNotFoundException{
		String sql = "DELETE FROM assets WHERE asset_id=?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            int affected = ps.executeUpdate();
            if (affected == 0) throw new AssetNotFoundException("Asset with ID " + assetId + " not found.");
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
	}

	@Override
	public boolean allocateAsset(int assetId, int employeeId, String allocationDate)  throws AssetNotFoundException {
		String checkSql = "SELECT * FROM assets WHERE asset_id = ?";
        String insertSql = "INSERT INTO asset_allocations (asset_id, employee_id, allocation_date) VALUES (?, ?, ?)";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setInt(1, assetId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next()) throw new AssetNotFoundException("Asset ID " + assetId + " not found.");

            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setInt(1, assetId);
                insertStmt.setInt(2, employeeId);
                insertStmt.setDate(3, Date.valueOf(allocationDate));
                return insertStmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
		
	}

	@Override
	public boolean deallocateAsset(int assetId, int employeeId, String returnDate) {
		  String sql = "UPDATE asset_allocations SET return_date=? WHERE asset_id=? AND employee_id=? AND return_date IS NULL";
	        try (Connection conn = DBConnUtil.getConnection();
	             PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setDate(1, Date.valueOf(returnDate));
	            ps.setInt(2, assetId);
	            ps.setInt(3, employeeId);
	            return ps.executeUpdate() > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	}

	@Override
	public boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost) throws AssetNotMaintainException {
		
		String checkSql = "SELECT MAX(maintenance_date) AS last_date FROM maintenance_records WHERE asset_id = ?";
        String insertSql = "INSERT INTO maintenance_records (asset_id, maintenance_date, description, cost) VALUES (?, ?, ?, ?)";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setInt(1, assetId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getDate("last_date") != null) {
                Date lastDate = rs.getDate("last_date");
                Date twoYearsAgo = Date.valueOf(LocalDate.now().minusYears(2));
                if (lastDate.before(twoYearsAgo)) {
                    throw new AssetNotMaintainException("Asset maintenance overdue for 2+ years.");
                }
            }
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                insertStmt.setInt(1, assetId);
                insertStmt.setDate(2, Date.valueOf(maintenanceDate));
                insertStmt.setString(3, description);
                insertStmt.setDouble(4, cost);
                return insertStmt.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
	}

	@Override
	public boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate) {
		String sql = "INSERT INTO reservations (asset_id, employee_id, reservation_date, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, 'pending')";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, assetId);
            ps.setInt(2, employeeId);
            ps.setDate(3, Date.valueOf(reservationDate));
            ps.setDate(4, Date.valueOf(startDate));
            ps.setDate(5, Date.valueOf(endDate));
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
	}

	@Override
	public boolean withdrawReservation(int reservationId) {
		 String sql = "UPDATE reservations SET status='cancelled' WHERE reservation_id=?";
	        try (Connection conn = DBConnUtil.getConnection();
	             PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setInt(1, reservationId);
	            return ps.executeUpdate() > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	}

	@Override
	public void showCOnnection() {
		System.out.println("COnnection Established : " + conn);
		
	}

}
