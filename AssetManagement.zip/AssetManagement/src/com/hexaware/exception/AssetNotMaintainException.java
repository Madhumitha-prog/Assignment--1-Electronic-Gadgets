package com.hexaware.exception;

public class AssetNotMaintainException extends Exception {
	 public AssetNotMaintainException(String message) {
	        super(message);
	    }

}
